import 'dart:math';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../library_store.dart';
import '../models.dart';
import '../player_controller.dart';
import '../theme.dart';
import '../widgets/bottom_deck.dart';
import '../widgets/cover_image.dart';
import '../widgets/menus.dart';

class AlbumScreen extends StatelessWidget {
  const AlbumScreen({super.key, required this.album});

  final Album album;

  @override
  Widget build(BuildContext context) {
    final store = context.watch<LibraryStore>();
    final pl = context.watch<PlayerController>();
    final refs = store.tracksOf(album);
    final curId = pl.current?.track.id;

    return Scaffold(
      appBar: AppBar(
        actions: [
          IconButton(
            tooltip: album.pinned ? 'Unpin' : 'Pin to top',
            icon: Icon(album.pinned ? Icons.push_pin : Icons.push_pin_outlined,
                color: kOrange),
            onPressed: () => store.togglePin(album),
          ),
          IconButton(
            icon: const Icon(Icons.more_vert),
            onPressed: () => showAlbumMenu(context, album,
                onDeleted: () => Navigator.of(context).maybePop()),
          ),
        ],
      ),
      bottomNavigationBar: const BottomDeck(showAdd: false),
      body: ListView(
        padding: const EdgeInsets.only(bottom: 16),
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 48),
            child: AspectRatio(
              aspectRatio: 1,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(14),
                child: CoverImage(path: album.coverPath, cacheWidth: 900),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 22, 20, 4),
            child: Text(album.title,
                style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Text(
              '${album.artist}  ·  ${album.tracks.length} tracks',
              style: const TextStyle(color: kMuted, fontSize: 16),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 18, 20, 10),
            child: Row(
              children: [
                FilledButton.icon(
                  style: FilledButton.styleFrom(
                    backgroundColor: kOrange,
                    foregroundColor: Colors.black,
                    padding:
                        const EdgeInsets.symmetric(horizontal: 28, vertical: 16),
                  ),
                  onPressed: () => pl.playQueue(refs, 0),
                  icon: const Icon(Icons.play_arrow_rounded),
                  label: const Text('PLAY',
                      style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
                ),
                const SizedBox(width: 12),
                IconButton.outlined(
                  onPressed: () => pl.playQueue(
                      refs, Random().nextInt(max(1, refs.length)),
                      shuffleOn: true),
                  icon: const Icon(Icons.shuffle_rounded),
                ),
              ],
            ),
          ),
          for (var i = 0; i < refs.length; i++)
            ListTile(
              onTap: () => pl.playQueue(refs, i),
              contentPadding: const EdgeInsets.only(left: 20, right: 4),
              leading: SizedBox(
                width: 28,
                child: Center(
                  child: curId == refs[i].track.id
                      ? Icon(pl.playing ? Icons.graphic_eq : Icons.pause,
                          color: kOrange)
                      : Text('${i + 1}', style: const TextStyle(color: kMuted)),
                ),
              ),
              title: Text(
                refs[i].track.title,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                  color: curId == refs[i].track.id ? kOrange : Colors.white,
                ),
              ),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (refs[i].track.isVideo)
                    const Icon(Icons.videocam_outlined, size: 18, color: kMuted),
                  IconButton(
                    icon: const Icon(Icons.more_vert, color: kMuted),
                    onPressed: () => showTrackMenu(context, refs[i]),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}
