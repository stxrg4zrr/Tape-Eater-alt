import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import 'importer.dart';
import 'models.dart';

enum SortMode { titleAsc, titleDesc, artistAsc, newest }

class ImportResult {
  const ImportResult(this.ok, this.failures);
  final int ok;
  final List<String> failures;
}

class LibraryStore extends ChangeNotifier {
  LibraryStore._(this._albumBox, this._playlistBox, this._prefs);

  final Box<String> _albumBox;
  final Box<String> _playlistBox;
  final Box<String> _prefs;

  List<Album> _albums = [];
  List<Playlist> _playlists = [];
  Map<String, TrackRef> _index = {};

  String query = '';
  SortMode sort = SortMode.titleAsc;
  bool importing = false;
  String? status;
  double? progress;

  static Future<LibraryStore> open() async {
    final a = await Hive.openBox<String>('albums');
    final pl = await Hive.openBox<String>('playlists');
    final pr = await Hive.openBox<String>('prefs');
    final s = LibraryStore._(a, pl, pr);
    s._load();
    await s._ensureFavorites();
    return s;
  }

  // ---------------------------------------------------------------- loading

  void _load() {
    final albums = <Album>[];
    for (final v in _albumBox.values) {
      try {
        albums.add(Album.fromJson(Map<String, dynamic>.from(jsonDecode(v) as Map)));
      } catch (_) {}
    }
    _albums = albums;

    final lists = <Playlist>[];
    for (final v in _playlistBox.values) {
      try {
        lists.add(Playlist.fromJson(Map<String, dynamic>.from(jsonDecode(v) as Map)));
      } catch (_) {}
    }
    _playlists = lists;

    final s = int.tryParse(_prefs.get('sort') ?? '');
    if (s != null && s >= 0 && s < SortMode.values.length) sort = SortMode.values[s];

    _reindex();
    for (final pl in _playlists) {
      pl.trackIds.removeWhere((id) => !_index.containsKey(id));
    }
  }

  void _reindex() {
    _index = {
      for (final a in _albums)
        for (final t in a.tracks) t.id: TrackRef(t, a),
    };
  }

  Future<void> _ensureFavorites() async {
    if (_playlists.any((x) => x.isFavorites)) return;
    final fav = Playlist(id: 'favorites', name: 'Favorites', colorValue: 0xFFFF5500);
    _playlists.add(fav);
    await _savePlaylist(fav);
  }

  // ------------------------------------------------------------------ albums

  int get count => _albums.length;
  int get trackCount => _index.length;
  int get artistCount => _albums.map((a) => a.artist.toLowerCase()).toSet().length;

  TrackRef? ref(String trackId) => _index[trackId];

  List<TrackRef> tracksOf(Album a) =>
      a.tracks.map((t) => TrackRef(t, a)).toList();

  /// Key used for sorting and for the alphabet scroller.
  String keyOf(Album a) => sort == SortMode.artistAsc ? a.artist : a.title;

  Iterable<Album> _filtered() {
    final q = query.trim().toLowerCase();
    if (q.isEmpty) return _albums;
    return _albums.where((a) =>
        a.title.toLowerCase().contains(q) || a.artist.toLowerCase().contains(q));
  }

  int _cmp(Album a, Album b) {
    switch (sort) {
      case SortMode.titleAsc:
        return a.title.toLowerCase().compareTo(b.title.toLowerCase());
      case SortMode.titleDesc:
        return b.title.toLowerCase().compareTo(a.title.toLowerCase());
      case SortMode.artistAsc:
        {
          final c = a.artist.toLowerCase().compareTo(b.artist.toLowerCase());
          return c != 0 ? c : a.title.toLowerCase().compareTo(b.title.toLowerCase());
        }
      case SortMode.newest:
        return b.addedAt.compareTo(a.addedAt);
    }
  }

  List<Album> get albums => _filtered().toList()..sort(_cmp);
  List<Album> get pinned => _filtered().where((a) => a.pinned).toList()..sort(_cmp);

  List<TrackRef> get allAudio {
    final all = <TrackRef>[];
    for (final a in _albums) {
      for (final t in a.tracks) {
        if (!t.isVideo) all.add(TrackRef(t, a));
      }
    }
    if (all.isNotEmpty) return all;
    return [
      for (final a in _albums)
        for (final t in a.tracks) TrackRef(t, a),
    ];
  }

  List<TrackRef> get videos {
    final q = query.trim().toLowerCase();
    final out = <TrackRef>[];
    for (final a in _albums) {
      for (final t in a.tracks) {
        if (!t.isVideo) continue;
        if (q.isNotEmpty &&
            !t.title.toLowerCase().contains(q) &&
            !a.title.toLowerCase().contains(q) &&
            !a.artist.toLowerCase().contains(q)) {
          continue;
        }
        out.add(TrackRef(t, a));
      }
    }
    out.sort((x, y) => x.track.title.toLowerCase().compareTo(y.track.title.toLowerCase()));
    return out;
  }

  void setQuery(String q) {
    query = q;
    notifyListeners();
  }

  Future<void> setSort(SortMode m) async {
    sort = m;
    await _prefs.put('sort', m.index.toString());
    notifyListeners();
  }

  Future<void> _saveAlbum(Album a) => _albumBox.put(a.id, jsonEncode(a.toJson()));

  Future<void> togglePin(Album a) async {
    a.pinned = !a.pinned;
    await _saveAlbum(a);
    notifyListeners();
  }

  Future<void> updateAlbum(
    Album a, {
    required String title,
    required String artist,
    Map<String, String> trackTitles = const {},
  }) async {
    if (title.trim().isNotEmpty) a.title = title.trim();
    if (artist.trim().isNotEmpty) a.artist = artist.trim();
    for (final t in a.tracks) {
      final nt = trackTitles[t.id];
      if (nt != null && nt.trim().isNotEmpty) t.title = nt.trim();
    }
    await _saveAlbum(a);
    notifyListeners();
  }

  Future<void> setAlbumCover(Album a, String srcPath) async {
    final ext = p.extension(srcPath).isEmpty ? '.jpg' : p.extension(srcPath);
    final dest = p.join(a.dirPath, 'cover_custom_${DateTime.now().millisecondsSinceEpoch}$ext');
    await File(srcPath).copy(dest);
    final old = a.coverPath;
    a.coverPath = dest;
    if (old != null && p.basename(old).startsWith('cover_custom_')) {
      try {
        await File(old).delete();
      } catch (_) {}
    }
    await _saveAlbum(a);
    notifyListeners();
  }

  Future<void> deleteAlbum(Album a) async {
    final ids = a.tracks.map((t) => t.id).toSet();
    _albums.removeWhere((x) => x.id == a.id);
    _reindex();
    await _albumBox.delete(a.id);
    for (final pl in _playlists) {
      final before = pl.trackIds.length;
      pl.trackIds.removeWhere(ids.contains);
      if (pl.trackIds.length != before) await _savePlaylist(pl);
    }
    try {
      await Directory(a.dirPath).delete(recursive: true);
    } catch (_) {}
    notifyListeners();
  }

  // ---------------------------------------------------------------- playlists

  Playlist get favorites => _playlists.firstWhere((x) => x.isFavorites);

  List<Playlist> get playlists {
    final q = query.trim().toLowerCase();
    final l = _playlists
        .where((x) => q.isEmpty || x.name.toLowerCase().contains(q))
        .toList();
    l.sort((a, b) {
      if (a.isFavorites) return -1;
      if (b.isFavorites) return 1;
      return a.name.toLowerCase().compareTo(b.name.toLowerCase());
    });
    return l;
  }

  List<TrackRef> playlistTracks(Playlist x) =>
      x.trackIds.map((id) => _index[id]).whereType<TrackRef>().toList();

  int get playlistTrackTotal {
    final ids = <String>{};
    for (final x in _playlists) {
      ids.addAll(x.trackIds);
    }
    return ids.length;
  }

  int get playlistArtistTotal {
    final artists = <String>{};
    for (final x in _playlists) {
      for (final id in x.trackIds) {
        final r = _index[id];
        if (r != null) artists.add(r.album.artist.toLowerCase());
      }
    }
    return artists.length;
  }

  Future<void> _savePlaylist(Playlist x) =>
      _playlistBox.put(x.id, jsonEncode(x.toJson()));

  Future<Playlist> createPlaylist(String name, int colorValue) async {
    final x = Playlist(
      id: 'pl_${DateTime.now().microsecondsSinceEpoch}',
      name: name.trim().isEmpty ? 'New playlist' : name.trim(),
      colorValue: colorValue,
    );
    _playlists.add(x);
    await _savePlaylist(x);
    notifyListeners();
    return x;
  }

  Future<void> updatePlaylist(Playlist x, {String? name, int? colorValue}) async {
    if (name != null && name.trim().isNotEmpty && !x.isFavorites) x.name = name.trim();
    if (colorValue != null) x.colorValue = colorValue;
    await _savePlaylist(x);
    notifyListeners();
  }

  Future<void> setPlaylistCover(Playlist x, String srcPath) async {
    final dir = await getApplicationSupportDirectory();
    final d = Directory(p.join(dir.path, 'playlist_covers'));
    await d.create(recursive: true);
    final ext = p.extension(srcPath).isEmpty ? '.jpg' : p.extension(srcPath);
    final dest = p.join(d.path, '${x.id}_${DateTime.now().millisecondsSinceEpoch}$ext');
    await File(srcPath).copy(dest);
    final old = x.coverPath;
    x.coverPath = dest;
    if (old != null) {
      try {
        await File(old).delete();
      } catch (_) {}
    }
    await _savePlaylist(x);
    notifyListeners();
  }

  Future<void> deletePlaylist(Playlist x) async {
    if (x.isFavorites) return;
    _playlists.removeWhere((y) => y.id == x.id);
    await _playlistBox.delete(x.id);
    if (x.coverPath != null) {
      try {
        await File(x.coverPath!).delete();
      } catch (_) {}
    }
    notifyListeners();
  }

  Future<int> addToPlaylist(Playlist x, List<String> ids) async {
    var added = 0;
    for (final id in ids) {
      if (!x.trackIds.contains(id) && _index.containsKey(id)) {
        x.trackIds.add(id);
        added++;
      }
    }
    if (added > 0) {
      await _savePlaylist(x);
      notifyListeners();
    }
    return added;
  }

  Future<void> removeFromPlaylist(Playlist x, String id) async {
    x.trackIds.remove(id);
    await _savePlaylist(x);
    notifyListeners();
  }

  Future<void> reorderPlaylist(Playlist x, int oldIndex, int newIndex) async {
    if (oldIndex < 0 || oldIndex >= x.trackIds.length) return;
    final id = x.trackIds.removeAt(oldIndex);
    x.trackIds.insert(newIndex.clamp(0, x.trackIds.length).toInt(), id);
    await _savePlaylist(x);
    notifyListeners();
  }

  bool isFavorite(String trackId) => favorites.trackIds.contains(trackId);

  Future<void> toggleFavorite(String trackId) async {
    final f = favorites;
    if (f.trackIds.contains(trackId)) {
      f.trackIds.remove(trackId);
    } else if (_index.containsKey(trackId)) {
      f.trackIds.add(trackId);
    }
    await _savePlaylist(f);
    notifyListeners();
  }

  // ------------------------------------------------------------------ import

  void _deleteCached(String path) {
    try {
      if (path.contains('/cache/')) File(path).deleteSync();
    } catch (_) {}
  }

  /// Each entry is zipPath -> display name. One bad zip never stops the rest.
  Future<ImportResult> importZips(List<MapEntry<String, String>> zips) async {
    importing = true;
    progress = 0;
    notifyListeners();
    var ok = 0;
    final failures = <String>[];

    for (var i = 0; i < zips.length; i++) {
      final z = zips[i];
      status = 'Eating ${i + 1} of ${zips.length}\n${z.value}';
      progress = i / zips.length;
      notifyListeners();
      try {
        final a = await Importer.importZip(z.key, z.value);
        _albums.add(a);
        _reindex();
        await _saveAlbum(a);
        ok++;
        notifyListeners();
      } catch (e) {
        final msg = e.toString().replaceFirst('Exception: ', '');
        failures.add('${z.value}: $msg');
      } finally {
        _deleteCached(z.key);
      }
    }

    importing = false;
    status = null;
    progress = null;
    notifyListeners();
    return ImportResult(ok, failures);
  }
}
