import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:just_audio_background/just_audio_background.dart';
import 'package:provider/provider.dart';

import 'library_store.dart';
import 'player_controller.dart';
import 'screens/home_screen.dart';
import 'theme.dart';
import 'utils.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Lock-screen + quick-settings media controls.
  await JustAudioBackground.init(
    androidNotificationChannelId: 'com.mixtape.mixtape_deck.audio',
    androidNotificationChannelName: 'Tape Eater playback',
    androidNotificationOngoing: true,
  );

  await Hive.initFlutter();
  await prepareDefaultCover();
  final store = await LibraryStore.open();

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider<LibraryStore>.value(value: store),
        ChangeNotifierProvider<PlayerController>(create: (_) => PlayerController()),
      ],
      child: const TapeEaterApp(),
    ),
  );
}

class TapeEaterApp extends StatelessWidget {
  const TapeEaterApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Tape Eater',
      debugShowCheckedModeBanner: false,
      theme: buildTheme(),
      home: const HomeScreen(),
    );
  }
}
